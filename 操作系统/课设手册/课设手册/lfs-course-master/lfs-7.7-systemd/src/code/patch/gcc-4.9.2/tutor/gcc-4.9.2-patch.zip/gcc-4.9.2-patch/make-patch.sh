
# First, prepare the patch
diff -uN old/gcc/cp/cfns.h new/gcc/cp/cfns.h > cfns-new.patch

# Then in the gcc-4.9.2, do this
patch -p1 < cfns-new.patch

