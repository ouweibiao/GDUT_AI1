package com.hilary.ping;

public class Main {
	public static void main(String args[]){
		new MainFrame().setVisible(true);//��ʾ����
	}
}