package com.sxl.util;

import java.util.Map;


/* 请关注微信公众号：bysjbng,各种免费毕设相关模板提供下载*/
public class TagParams {
	private Map<Long, String> tagParmsValue;

	public Map<Long, String> getTagParmsValue() {
		return tagParmsValue;
	}

	public void setTagParmsValue(Map<Long, String> tagParmsValue) {
		this.tagParmsValue = tagParmsValue;
	}

}
